TRAVEL YOUR JOURNEY — STATIC SITE (GoDaddy cPanel)
1) Upload all files to public_html and ensure index.html is at root.
2) Forms:
   - Planner on Home submits to lead.php (stores CSV at cms/leads.csv and opens WhatsApp).
   - Contact form posts to contact.php (emails info.travelyourjourney@gmail.com and stores CSV at cms/contacts.csv). Use domain email for From.
3) Replace example.com in canonical/JSON-LD and sitemap with your domain.
4) Replace Unsplash image URLs with your own if desired.
